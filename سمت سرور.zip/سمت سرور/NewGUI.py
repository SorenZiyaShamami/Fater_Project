import re
from fileinput import close
from http.client import responses

import customtkinter as ctk
from tkinter import messagebox, filedialog
import os

import requests

# کانفیگ ها
curent_user = {"username": "soren" , "password": "soren1383"}
the_url = "http://127.0.0.1:5000"




#فونت
DEFAULT_FONT = ("Vazir", 14)
TITLE_FONT = ("Vazir", 18, "bold")
SUBTITLE_FONT = ("Vazir", 16, "bold")



def center_window(window, width, height):

    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()


    x = (screen_width // 2) - (width // 2)
    y = (screen_height // 2) - (height // 2)


    window.geometry(f"{width}x{height}+{x}+{y}")

#نمایش لیست درس

def show_courses():
    def search_api ():
        adress = the_url + "/neshan_dadan_dars_qabel_axz"
        output =[]
        data={
            "username": curent_user["username"],
            "password": curent_user["password"],
            "onvan_dars" : entry_course.get().replace("ي" , "ی"),
            "nimsal": entry_sem.get(),
            "sal" :entry_year.get(),
            "name_ostad":entry_prof.get().replace("ي" , "ی")
        }

        response = requests.post(adress, data=data)


        if response.status_code != 200:
            print("در ارتباط با سرور مشکلی پیش آمد")
        else:
            output = response.json()
            for course in output :
                course_frame = ctk.CTkFrame(courses_frame, height=40, corner_radius=5)
                course_frame.pack(fill="x", pady=2, padx=5)

                label_text = f"{course['course_id']} | {course['title']} | {course['teacher_id']} | {course['year']} | {course['half_year']} | {course['vahed_ha']} واحد"
                ctk.CTkLabel(course_frame, text=label_text, anchor="e", font=DEFAULT_FONT).pack(side="right", padx=5)

                ctk.CTkButton(course_frame, text="جزئیات", width=70, font=DEFAULT_FONT,
                              command=lambda c=course: show_course_details(c)).pack(side="left", padx=5)
                ctk.CTkButton(course_frame, text="درخواست اخذ", width=90, font=DEFAULT_FONT,
                              command=lambda c=course: request_course(c)).pack(side="left", padx=5)



    for widget in frame_content.winfo_children():
        widget.destroy()

    search_frame = ctk.CTkFrame(frame_content, height=50)
    search_frame.pack(fill="x", pady=5)

    ctk.CTkLabel(search_frame, text="جست و جو بر اساس: ", anchor="e", font=DEFAULT_FONT).pack(side="right", padx=5)

    entry_course = ctk.CTkEntry(search_frame, placeholder_text="درس", width=100, justify="right", font=DEFAULT_FONT)
    entry_course.pack(side="right", padx=5)

    entry_sem = ctk.CTkEntry(search_frame, placeholder_text="نیم سال", width=80, justify="right", font=DEFAULT_FONT)
    entry_sem.pack(side="right", padx=5)

    entry_year = ctk.CTkEntry(search_frame, placeholder_text="سال", width=70, justify="right", font=DEFAULT_FONT)
    entry_year.pack(side="right", padx=5)

    entry_prof = ctk.CTkEntry(search_frame, placeholder_text="استاد", width=100, justify="right", font=DEFAULT_FONT)
    entry_prof.pack(side="right", padx=5)

    def search_courses():

        for widget in courses_frame.winfo_children():
            widget.destroy()

        search_api()


    ctk.CTkButton(search_frame, text="جستجو", width=70, font=DEFAULT_FONT, command=search_courses).pack(side="right",
                                                                                                        padx=5)

    courses_frame = ctk.CTkScrollableFrame(frame_content)
    courses_frame.pack(fill="both", expand=True, pady=5)


    search_api()



def show_course_details(course):
    details = f"""
کد درس: {course['course_id']}
عنوان: {course['title']}
استاد: {course['teacher_id']}
سال: {course['year']}
نیمسال: {course['half_year']}
تعداد واحد: {course['vahed_ha']}
"""
    messagebox.showinfo("جزئیات درس", details)


def request_course(course):
    data = {"username": curent_user["username"],
            "password": curent_user["password"],
            "course_id": course["course_id"],
            }
    response = requests.post(the_url+"/axze_dars" , data=data)
    if response.status_code == 200 and response.json()["SUC"] == True :
        messagebox.showinfo("نتیجه", "درس با موفقیت ثبت شد")
    else:
        messagebox.showinfo("عملیات با موفقیت شکست خورد", response.json()["message"])


# مشاهده ی وضعیت درخواست
def show_requests():
    for widget in frame_content.winfo_children():
        widget.destroy()

    title_label = ctk.CTkLabel(frame_content, text="وضعیت درخواست‌های من", font=TITLE_FONT)
    title_label.pack(pady=10)

    requests_frame = ctk.CTkScrollableFrame(frame_content)
    requests_frame.pack(fill="both", expand=True, pady=5)

    data = {"username": curent_user["username"],
            "password": curent_user["password"],
            }
    response = requests.post(the_url+"/vaziyate_darxast_ha_student" , data=data)

    student_requests = response.json()
    print(student_requests)

    if not student_requests:
        ctk.CTkLabel(requests_frame, text="هیچ درخواستی یافت نشد", font=DEFAULT_FONT).pack(pady=20)
        return

    for req in student_requests:
        req_frame = ctk.CTkFrame(requests_frame, height=40, corner_radius=5)
        req_frame.pack(fill="x", pady=2, padx=5)

        status_color = "green" if req['status'] == "قبول شد" else "red" if req['status'] == "رد شد" else "orange"

        label_text = f"{req['id']} | {req.get('course', 'درخواست دفاع')} | {req['master_name']} | {req['status']}"
        ctk.CTkLabel(req_frame, text=label_text, anchor="e", font=DEFAULT_FONT,
                     text_color=status_color).pack(side="right", padx=5)

        ctk.CTkButton(req_frame, text="جزئیات", width=70, font=DEFAULT_FONT,
                      command=lambda r=req: show_request_details(r)).pack(side="left", padx=5)


def show_request_details(request):
    details = f"""
شناسه درخواست: {request['id']}
استاد: {request['master_name']}
وضعیت: {request['status']}
"""
    messagebox.showinfo("جزئیات درخواست", details)


#جست و جو در پایان نامه ها
def show_theses():
    for widget in frame_content.winfo_children():
        widget.destroy()

    search_frame = ctk.CTkFrame(frame_content, height=50)
    search_frame.pack(fill="x", pady=5)

    ctk.CTkLabel(search_frame, text="جستجو در پایان‌نامه‌ها: ", anchor="e", font=DEFAULT_FONT).pack(side="right",
                                                                                                    padx=5)

    entry_keyword = ctk.CTkEntry(search_frame, placeholder_text="کلمه کلیدی", width=120, justify="right",
                                 font=DEFAULT_FONT)
    entry_keyword.pack(side="right", padx=5)

    entry_author = ctk.CTkEntry(search_frame, placeholder_text="نویسنده", width=100, justify="right", font=DEFAULT_FONT)
    entry_author.pack(side="right", padx=5)

    entry_year = ctk.CTkEntry(search_frame, placeholder_text="سال", width=70, justify="right", font=DEFAULT_FONT)
    entry_year.pack(side="right", padx=5)

    def search_theses():

        for widget in theses_frame.winfo_children():
            widget.destroy()
        data = {"username": curent_user["username"],
                "password": curent_user["password"],
                "nevisande": entry_author.get(),
                "sal": entry_year.get(),
                "kalamate_kelidi": entry_keyword.get()
                }

        response = requests.post(the_url + "/josto_ju_dar_banke_payannameh", data=data)
        theses = response.json()

        for thesis in theses:
            print(thesis)
            thesis_frame = ctk.CTkFrame(theses_frame, height=40, corner_radius=5)
            thesis_frame.pack(fill="x", pady=2, padx=5)

            avg = 12
            numbers = re.findall(r"\d+", thesis["AsatideRahnemaVaNomarateshunDefa"])
            numbers = list(map(int, numbers))
            if numbers:
                avg = sum(numbers) / len(numbers)

            label_text = f"{thesis['OnvaneMaghaleDefa']} | {thesis['Student_id']} | {thesis['TarixeDarxasteDefa']} | نمره: {avg}"
            ctk.CTkLabel(thesis_frame, text=label_text, anchor="e", font=DEFAULT_FONT).pack(side="right", padx=5)

            ctk.CTkButton(thesis_frame, text="جزئیات", width=70, font=DEFAULT_FONT,
                          command=lambda t=thesis: show_thesis_details(t)).pack(side="left", padx=5)
            ctk.CTkButton(thesis_frame, text="مشاهده فایل", width=90, font=DEFAULT_FONT,
                          command=lambda t=thesis: open_thesis_file(t)).pack(side="left", padx=5)


    ctk.CTkButton(search_frame, text="جستجو", width=70, font=DEFAULT_FONT, command=search_theses).pack(side="right",
                                                                                                       padx=5)

    theses_frame = ctk.CTkScrollableFrame(frame_content)
    theses_frame.pack(fill="both", expand=True, pady=5)
    search_theses()




def show_thesis_details(thesis):
    avg = 0
    numbers = re.findall(r"\d+", thesis["AsatideRahnemaVaNomarateshunDefa"])
    numbers = list(map(int, numbers))
    if numbers:
        avg = sum(numbers) / len(numbers)

    details = f"""
عنوان: {thesis['OnvaneMaghaleDefa']}
نویسنده: {thesis['Student_id']}
سال: {thesis['TarixeDarxasteDefa']}
کلمات کلیدی: {thesis['KalamateKelidiDefa']}
استاد راهنما: {thesis['OstadAsliId']}
داوران: {thesis['AsatideRahnemaVaNomarateshunDefa']}
نمره: {avg}
چکیده: {thesis['ChekideMaghaleDefa']}
"""
    messagebox.showinfo("جزئیات پایان‌نامه", details)


def open_thesis_file(thesis):
    adr = the_url  + thesis["FayleNahayiDefa"]
    response = requests.get(adr)
    save_path = filedialog.asksaveasfilename(title="محل ذخیره فایل")
    with open(save_path.title(), "wb") as f:
        f.write(response.content)
        os.startfile(save_path.title())
    f.close()

# درخواست دفاع
def request_defense():
    for widget in frame_content.winfo_children():
        widget.destroy()

    title_label = ctk.CTkLabel(frame_content, text="درخواست دفاع از پایان‌نامه", font=TITLE_FONT)
    title_label.pack(pady=10)

    form_frame = ctk.CTkFrame(frame_content)
    form_frame.pack(fill="x", pady=10, padx=20)

    # Title
    ctk.CTkLabel(form_frame, text="عنوان پایان‌نامه:", font=DEFAULT_FONT, anchor="e").grid(row=0, column=1, padx=5,
                                                                                           pady=5, sticky="e")
    entry_title = ctk.CTkEntry(form_frame, width=300, font=DEFAULT_FONT, justify="right")
    entry_title.grid(row=0, column=0, padx=5, pady=5, sticky="ew")

    # Supervisor
    ctk.CTkLabel(form_frame, text="استاد راهنما(کدش رو بزنید):", font=DEFAULT_FONT, anchor="e").grid(row=1, column=1, padx=5, pady=5,
                                                                                       sticky="e")
    entry_supervisor = ctk.CTkEntry(form_frame, width=300, font=DEFAULT_FONT, justify="right")
    entry_supervisor.grid(row=1, column=0, padx=5, pady=5, sticky="ew")

    # Reviewers
    ctk.CTkLabel(form_frame, text="داوران (کداشونو بزنید با فاصله جدا کنید):", font=DEFAULT_FONT, anchor="e").grid(row=2, column=1,
                                                                                                    padx=5, pady=5,
                                                                                                    sticky="e")
    entry_reviewers = ctk.CTkEntry(form_frame, width=300, font=DEFAULT_FONT, justify="right")
    entry_reviewers.grid(row=2, column=0, padx=5, pady=5, sticky="ew")

    # Abstract
    ctk.CTkLabel(form_frame, text="چکیده:", font=DEFAULT_FONT, anchor="e").grid(row=3, column=1, padx=5, pady=5,
                                                                                sticky="ne")
    text_abstract = ctk.CTkTextbox(form_frame, width=300, height=100, font=DEFAULT_FONT)
    text_abstract.grid(row=3, column=0, padx=5, pady=5, sticky="ew")

    # Keywords
    ctk.CTkLabel(form_frame, text="کلمات کلیدی (به هشتگ جدا کنید):", font=DEFAULT_FONT, anchor="e").grid(row=4, column=1, padx=5, pady=5,
                                                                                      sticky="e")
    entry_keywords = ctk.CTkEntry(form_frame, width=300, font=DEFAULT_FONT, justify="right")
    entry_keywords.grid(row=4, column=0, padx=5, pady=5, sticky="ew")
    file_path_last = []
    # File upload
    def upload_file():
        file_path = filedialog.askopenfilename(
            title="انتخاب فایل پایان‌نامه",
            filetypes=[("PDF files", "*.pdf"), ("Word documents", "*.docx"), ("All files", "*.*")]
        )
        if file_path:
            file_name.set(os.path.basename(file_path))
        return file_path.title()

    file_name = ctk.StringVar(value="هیچ فایلی انتخاب نشده")
    ctk.CTkLabel(form_frame, text="فایل پایان‌نامه:", font=DEFAULT_FONT, anchor="e").grid(row=5, column=1, padx=5,
                                                                                          pady=5, sticky="e")
    file_frame = ctk.CTkFrame(form_frame, fg_color="transparent")
    file_frame.grid(row=5, column=0, padx=5, pady=5, sticky="ew")
    ctk.CTkLabel(file_frame, textvariable=file_name, font=DEFAULT_FONT).pack(side="right", padx=5)
    ctk.CTkButton(file_frame, text="آپلود فایل", width=100, font=DEFAULT_FONT, command= lambda : file_path_last .append(upload_file())).pack(side="left")

    # Configure grid weights
    form_frame.columnconfigure(0, weight=1)
    form_frame.columnconfigure(1, weight=0)

    def submit_defense_request():
        title = entry_title.get()
        supervisor = entry_supervisor.get()
        reviewers = entry_reviewers.get()
        abstract = text_abstract.get("1.0", "end-1c")
        keywords = entry_keywords.get()

        if not all([title, supervisor, reviewers, abstract, keywords]) or file_name.get() == "هیچ فایلی انتخاب نشده":
            messagebox.showerror("خطا", "لطفاً تمام فیلدها را پر کنید")
            return
        link = ""
        with open(file_path_last[0], "rb") as f:
            files = {"file": f}
            response = requests.post(the_url + "/upload", files=files)
            link = response.json()["download_url"]
        f.close()

        data={
            "username" : curent_user["username"],
            "password": curent_user["password"],
            "title" : title ,
            "supervisor" : supervisor,
            "reviewers" : reviewers,
            "abstract" : abstract,
            "keywords" : keywords,
            "fileLiknk" : link

        }
        response = requests.post(the_url+"/darxaste_defa", data=data)
        if response.status_code != 200:
            messagebox.showinfo("با موفقیت شکست خورد", "در اتصال به سرور مشکلی روی داد")
        elif response.status_code == 200 :
            messagebox.showinfo("نتیجه", response.json().get("message"))


        show_requests()
    ctk.CTkButton(frame_content, text="ارسال درخواست", font=DEFAULT_FONT,
                  command=submit_defense_request).pack(pady=20)


# مدیریت درخواست دفاع از طرف استاد
def manage_defense_requests():
    for widget in frame_content.winfo_children():
        widget.destroy()

    title_label = ctk.CTkLabel(frame_content, text="مدیریت درخواست‌های دفاع", font=TITLE_FONT)
    title_label.pack(pady=10)

    date ={
        "username" : curent_user["username"],
        "password" : curent_user["password"]
    }

    response = requests.post(the_url+"/moshahede_darxaste_defa", data=date)
    defense_requests =response.json()

    if not defense_requests:
        ctk.CTkLabel(frame_content, text="هیچ درخواست دفاعی یافت نشد", font=DEFAULT_FONT).pack(pady=20)
        return

    requests_frame = ctk.CTkScrollableFrame(frame_content)
    requests_frame.pack(fill="both", expand=True, pady=5)

    for req in defense_requests:
        req_frame = ctk.CTkFrame(requests_frame, height=40, corner_radius=5)
        req_frame.pack(fill="x", pady=2, padx=5)

        label_text = f"{req['ID']} | {req['OnvaneMaghaleDefa']} | {req['Student_id']} | {req['VaziyateDefaDefa']}"
        ctk.CTkLabel(req_frame, text=label_text, anchor="e", font=DEFAULT_FONT).pack(side="right", padx=5)

        if req['VaziyateDefaDefa'] == "دربررسی":
            ctk.CTkButton(req_frame, text="تایید", width=60, font=DEFAULT_FONT, fg_color="green",
                          command=lambda: approve_defense(req)).pack(side="left", padx=5)

            ctk.CTkButton(req_frame, text="رد", width=60, font=DEFAULT_FONT, fg_color="red",
                          command=lambda: reject_defense(req)).pack(side="left", padx=5)

        else:
            ctk.CTkLabel(req_frame, text=req['VaziyateDefaDefa'], font=DEFAULT_FONT,
                         text_color="green" if req['VaziyateDefaDefa'] == "قبول شد" else "red").pack(side="left", padx=5)


def approve_defense(request):

    data={
        "username" : curent_user["username"],
        "password" : curent_user["password"],
        "req-id" :request["ID"]
    }
    response = requests.post(the_url+"/taid_darxaste_defa", data=data)
    if response.status_code == 200:
        if  response.json()['Suc'] :
            messagebox.showinfo("تایید درخواست دفاع", "درخواست دفاع با موفقیت تایید شد")
            manage_defense_requests()
        else:
            messagebox.showinfo("خطا", "مشکلی پیش آمد")
            manage_defense_requests()
    else:
        messagebox.showinfo("خطا", "در اتصال به سرور مشکل پیش آمد")
        manage_defense_requests()


def reject_defense(request):
    data = {
        "username": curent_user["username"],
        "password": curent_user["password"],
        "req-id": request["ID"]
    }
    response = requests.post(the_url + "/rade_darxaste_defa", data=data)
    if response.status_code == 200:
        messagebox.showinfo("رد درخواست دفاع", "درخواست دفاع با موفقیت رد شد")
        manage_defense_requests()
    else:
        messagebox.showinfo("خطا", "در اتصال به سرور مشکل پیش آمد")
        manage_defense_requests()


# ثبت نمرات داوری
def enter_review_scores():
    for widget in frame_content.winfo_children():
        widget.destroy()

    title_label = ctk.CTkLabel(frame_content, text="ثبت نمرات داوری", font=TITLE_FONT)
    title_label.pack(pady=10)

    response = requests.post(the_url+"/moshahede_liste_davari" , curent_user)
    professor_theses = response.json()

    if not professor_theses:
        ctk.CTkLabel(frame_content, text="هیچ پایان‌نامه‌ای برای داوری یافت نشد", font=DEFAULT_FONT).pack(pady=20)
        return

    theses_frame = ctk.CTkScrollableFrame(frame_content)
    theses_frame.pack(fill="both", expand=True, pady=5)

    for thesis in professor_theses:
        thesis_frame = ctk.CTkFrame(theses_frame, height=40, corner_radius=5)
        thesis_frame.pack(fill="x", pady=2, padx=5)

        label_text = f"{thesis['OnvaneMaghaleDefa']} | {thesis['Student_id']}"
        ctk.CTkLabel(thesis_frame, text=label_text, anchor="e", font=DEFAULT_FONT).pack(side="right", padx=5)

        score_var = ctk.StringVar(value="?")
        score_entry = ctk.CTkEntry(thesis_frame, width=50, textvariable=score_var, font=DEFAULT_FONT)
        score_entry.pack(side="left", padx=5)

        ctk.CTkLabel(thesis_frame, text="/20", font=DEFAULT_FONT).pack(side="left", padx=5)

        ctk.CTkButton(thesis_frame, text="ثبت نمره", width=80, font=DEFAULT_FONT,
                      command=lambda t=thesis, s=score_var: update_score(t, s)).pack(side="left", padx=5)


def update_score(thesis, score_var):

    try:
        score = float(score_var.get())
        if 0 <= score <= 20:
            thesis['score'] = f"{score}/20"
            messagebox.showinfo("اطلاعیه", "نمره با موفقیت ثبت شد")
        else:
            messagebox.showerror("خطا", "نمره باید بین 0 تا 20 باشد")
    except ValueError:
        messagebox.showerror("خطا", "لطفاً یک عدد معتبر وارد کنید")
    data = {
        "username": curent_user["username"],
        "password": curent_user["password"],
        "req-id": thesis["ID"],
        "grade" :score_var.get()

    }
    response = requests.post(the_url + "/sabte_nomreh_davari", data=data)

# داشبورد
def open_dashboard(user_type="student"):
    login_window.destroy()
    dashboard = ctk.CTk()
    dashboard.title("داشبورد")


    center_window(dashboard, 900, 500)

    global frame_content
    frame_content = ctk.CTkFrame(dashboard, width=600, height=500, corner_radius=10)
    frame_content.pack(side="left", fill="both", expand=True, padx=10, pady=10)

    frame_right = ctk.CTkFrame(dashboard, width=300, height=500, corner_radius=10)
    frame_right.pack(side="right", fill="y", padx=10, pady=10)

    user_frame = ctk.CTkFrame(frame_right, corner_radius=10)
    user_frame.pack(fill="x", pady=10)

    data = {
        "username": curent_user["username"]
    }
    response = requests.post(the_url + "/get_name", data=data)
    user_info = "نام:" +response.json().get("name") + "\n" + "نام کاربری:"+curent_user["username"]


    label_name = ctk.CTkLabel(user_frame, text=user_info, anchor="e", justify="right", font=DEFAULT_FONT)
    label_name.pack(side="right", padx=10, pady=10)

    photo = ctk.CTkLabel(user_frame, text="🖼️", width=60, height=60, fg_color="gray", corner_radius=10,
                         font=DEFAULT_FONT)
    photo.pack(side="left", padx=10, pady=10)

    label_dashboard = ctk.CTkLabel(frame_right, text="داشبورد", font=TITLE_FONT, anchor="e")
    label_dashboard.pack(pady=10)

    if user_type == "student":
        ctk.CTkButton(frame_right, text="اخذ و حذف درس", width=250, font=DEFAULT_FONT, command=show_courses).pack(
            pady=5)
        ctk.CTkButton(frame_right, text="مشاهده وضعیت درخواست ها", width=250, font=DEFAULT_FONT,
                      command=show_requests).pack(pady=5)
        ctk.CTkButton(frame_right, text="جستجو در پایان نامه ها", width=250, font=DEFAULT_FONT,
                      command=show_theses).pack(pady=5)
        ctk.CTkButton(frame_right, text="درخواست دفاع", width=250, font=DEFAULT_FONT, command=request_defense).pack(
            pady=5)
    else:  # استاد
        ctk.CTkButton(frame_right, text="مدیریت درخواست‌های دفاع", width=250, font=DEFAULT_FONT,
                      command=manage_defense_requests).pack(pady=5)
        ctk.CTkButton(frame_right, text="ثبت نمرات داوری", width=250, font=DEFAULT_FONT,
                      command=enter_review_scores).pack(pady=5)
        ctk.CTkButton(frame_right, text="جستجو در پایان نامه ها", width=250, font=DEFAULT_FONT,
                      command=show_theses).pack(pady=5)

    ctk.CTkButton(frame_right, text="خروج", width=250, font=DEFAULT_FONT, command=dashboard.destroy).pack(pady=5)


    if user_type == "student":
        show_courses()
    else:
        pass
        #manage_course_requests()

    dashboard.mainloop()


# ورود
def login():
    username = entry_username.get()
    password = entry_password.get()
    data ={
        "username":username,
        "password":password
    }
    resopnse = requests.post(the_url+"/login" , data=data)

    if resopnse.status_code != 200:
        messagebox.showerror(title="خطا", message="سرور قابل دسترسی نیست! ")
    else:
        if not resopnse.json()["Success"]:
            messagebox.showerror(title="خطا", message="نام کاربری یا رمز عبور اشتباه است ")
        else:
            curent_user["username"] = username
            curent_user["password"] = password
            if resopnse.json()["Rule"] == "student":
                open_dashboard(user_type="student")
            elif resopnse.json()["Rule"] == "master":
                open_dashboard(user_type="professor")



ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

login_window = ctk.CTk()
login_window.title("صفحه ورود")


center_window(login_window, 400, 300)

label_title = ctk.CTkLabel(login_window, text="صفحه ورود\nلطفاً رمز عبور را وارد کنید", font=TITLE_FONT, anchor="e",
                           justify="right")
label_title.pack(pady=20)

entry_username = ctk.CTkEntry(login_window, placeholder_text="نام کاربری", font=DEFAULT_FONT, justify="right")
entry_username.pack(pady=10, padx=20, fill="x")

entry_password = ctk.CTkEntry(login_window, placeholder_text="رمز عبور", font=DEFAULT_FONT, show="*", justify="right")
entry_password.pack(pady=10, padx=20, fill="x")

ctk.CTkButton(login_window, text="ورود", font=DEFAULT_FONT, command=login).pack(pady=20)

login_window.mainloop()