import hashlib
import json
import re
import uuid
from datetime import date , datetime

class Student:

    def __init__(self , hash_of_password ,username ,image ,name ):
        super().__setattr__('saving_buffer', {"hash_of_password": 0, "username": 0, "image": 0, "name": 0})
        self.hash_of_password = hash_of_password
        self.username = username
        self.image = image
        self.name = name

    def __setattr__(self , name , value):
        self.saving_buffer[name] = value
        super().__setattr__(name , value)

    def get_json_string (self):
        return json.dumps(self.saving_buffer)


    def load(self,json_string):
        self.saving_buffer= json.loads(json_string)
        #حالا اطلاعات رو تو متغیر های شی لود کن
        for name,value in self.saving_buffer.items():
            super().__setattr__(name, value)



class Master:


    def __init__(self, hash_of_password, username, image, name):
            super().__setattr__('saving_buffer' ,{"hash_of_password": 0, "username": 0, "image": 0, "name": 0} )
            self.hash_of_password = hash_of_password
            self.username = username
            self.image = image
            self.name = name

    def __setattr__(self, name, value):
            self.saving_buffer[name] = value
            super().__setattr__(name, value)

    def get_json_string(self):
            return json.dumps(self.saving_buffer)

    def load(self, json_string):
            self.saving_buffer = json.loads(json_string)
            # حالا اطلاعات رو تو متغیر های شی لود کن
            for name, value in self.saving_buffer.items():
                super().__setattr__(name, value)


class Course:

    #course_id = 0
    #title = 0
    #year = 0
    #half_year =0
    #capacity =0
    #refrences = 0
    #tedad_jalasat =0
    #vahed_ha =0
    #teacher_id = 0
    #is_sort_of_payan_name = False

    #saving_buffer = {"course_id": 0, "title": 0, "year": 0, "half_year": 0 , "capacity":0 , "refrences":0, "tedad_jalasat":0, "vahed_ha":0 , "teacher_id": 0 ,"is_sort_of_payan_name" : False}

    def __init__(self , cid , tit , yr , hy , cap , ref , tedad_j , vah , teacher_id , is_sort_of_payan_name = False):
        super().__setattr__('saving_buffer', {"course_id": 0, "title": 0, "year": 0, "half_year": 0 , "capacity":0 , "refrences":0, "tedad_jalasat":0, "vahed_ha":0 , "teacher_id": 0 ,"is_sort_of_payan_name" : False})
        self.course_id = cid
        self.title=tit
        self.year = yr
        self.half_year = hy
        self.capacity = cap
        self.refrences = ref
        self.tedad_jalasat = tedad_j
        self.vahed_ha = vah
        self.teacher_id = teacher_id
        self.is_sort_of_payan_name = is_sort_of_payan_name

    def __setattr__(self, name, value):
            self.saving_buffer[name] = value
            super().__setattr__(name, value)

    def get_json_string(self):
            return json.dumps(self.saving_buffer)

    def load(self, json_string):
            self.saving_buffer = json.loads(json_string)
            # حالا اطلاعات رو تو متغیر های شی لود کن
            for name, value in self.saving_buffer.items():
                super().__setattr__(name, value)

# اول تو اساتید راهنما و نمرات کده بعد جاش با نام استاد عوض میشه و نمره ی مد نظرش
class RequestForThesisDefense:

    def __init__(self,tarix ,fayl , onvan, chekide,kalamat,asatid,vaziya , ostad_asli_id , student_id):
        super().__setattr__('saving_buffer', {"ID" : 0,"TarixeDarxasteDefa" :0, "FayleNahayiDefa" :0 , "OnvaneMaghaleDefa" :0 , "ChekideMaghaleDefa" :0 , "KalamateKelidiDefa" :0 , "AsatideRahnemaVaNomarateshunDefa" :0 , "VaziyateDefaDefa" :0 , "OstadAsliId":0 , "Student_id":0 , "Ostad_QabulKard_Defa_Kone":False})
     
        self.ID = str(uuid.uuid4())
        self.TarixeDarxasteDefa = tarix
        self.FayleNahayiDefa = fayl
        self.OnvaneMaghaleDefa = onvan
        self.ChekideMaghaleDefa = chekide
        self.KalamateKelidiDefa = kalamat
        self.AsatideRahnemaVaNomarateshunDefa = asatid
        self.VaziyateDefaDefa = vaziya
        self.OstadAsliId = ostad_asli_id
        self.Student_id = student_id
        self.tedad_id_ha = len (self.AsatideRahnemaVaNomarateshunDefa.split())

    def kamel_shod (self):
        number = re.findall(r"\d+",self.TarixeDarxasteDefa)
        number = [int(num) for num in number]
        av = sum(number) / len(number)

        if self.tedad_id_ha != self.AsatideRahnemaVaNomarateshunDefa.count(":") :
            return False
        if av <10 :
            return False

        return True

    def __setattr__(self, name, value):
            self.saving_buffer[name] = value
            super().__setattr__(name, value)

    def get_json_string(self):
            return json.dumps(self.saving_buffer)

    def load(self, json_string):
            self.saving_buffer = json.loads(json_string)
            # حالا اطلاعات رو تو متغیر های شی لود کن
            for name, value in self.saving_buffer.items():
                super().__setattr__(name, value)

class DataBase:
    # دیتا بیس
    # قابل استقاده در برنامه
    masters = []
    courses = []
    requests = []
    students = []

    # اینا رو میریزن تو فایل
    masters_file = []
    courses_file = []
    requests_file = []
    students_file = []
    # اعضاش هست (_student_id ,courseid)
    #عضو سومشم هست تاریخ
    has_course = []
    tarixe_sabt = []
    # اعضاش هست request_for_defence
    request_for_thesis_defenses = []
    def __init__ (self):
        hashed_pass = hashlib.sha512("SorenZiyashamami".encode("utf-8")).hexdigest()
        self.students.append(Student(hashed_pass, "SorenZiyashamami", "SorenZiyashamami.jpg", "سورن ضیاشمامی"))

        hashed_pass = hashlib.sha512("SinaMoradi".encode("utf-8")).hexdigest()
        self.students.append(Student(hashed_pass, "SinaMoradi", "SinaMoradi.jpg", "سینا مرادی"))

        hashed_pass = hashlib.sha512("NimaImani".encode("utf-8")).hexdigest()
        self.students.append(Student(hashed_pass, "NimaImani", "NimaImani.jpg", "نیما ایمانی"))

        hashed_pass = hashlib.sha512("AbolfazlPashutan".encode("utf-8")).hexdigest()
        self.students.append(Student(hashed_pass, "AbolfazlPashutan", "AbolfazlPashutan.jpg", "ابوالفضل پشوتن"))

        hashed_pass = hashlib.sha512("SorenaZiyashamami".encode("utf-8")).hexdigest()
        self.students.append(Student(hashed_pass, "SorenaZiyashamami", "SorenaZiyashamami.jpg", "سورنا ضیاشمامی"))

        hashed_pass = hashlib.sha512("PuyaBagheri".encode("utf-8")).hexdigest()
        self.students.append(Student(hashed_pass, "PuyaBagheri", "PuyaBagheri.jpg", "پویا باقری"))

        #اساتید

        hashed_pass = hashlib.sha512("MehdiBagheri".encode("utf-8")).hexdigest()
        self.masters.append(Master(hashed_pass,"MehdiBagheri" , "MehdiBagheri.jpg" , "مهدی باقری"))

        hashed_pass = hashlib.sha512("NimaOmidifar".encode("utf-8")).hexdigest()
        self.masters.append(Master(hashed_pass, "NimaOmidifar", "NimaOmidifar.jpg", "نیما امیدیفر"))

        hashed_pass = hashlib.sha512("RoghayehShokuhmand".encode("utf-8")).hexdigest()
        self.masters.append(Master(hashed_pass, "RoghayehShokuhmand", "RoghayehShokuhmand.jpg", "رقیه شکوهمند"))

        hashed_pass = hashlib.sha512("AghayeHemmati".encode("utf-8")).hexdigest()
        self.masters.append(Master(hashed_pass, "AghayeHemmati", "AghayeHemmati.jpg", "عقب آقای همتی"))


        self.courses.append(Course("401", "ریاضیات خصوصی1", "1404", "1" , 3 , "کتاب دکتر به بهانی" ,"12" , "3" , "NimaOmidifar"))
        self.courses.append(
            Course("402", "اخلاق در کوانتوم", "1404", "1", 3, "کتاب حاج آقا بزرگ منش", "12", "3", "AghayeHemmati"))
        self.courses.append(
            Course("403", "پایان نامه", "1404", "1", 3, "ندارد", "12", "3",
                   "NimaOmidifar",True))
        self.courses.append(
            Course("404", "پایان نامه", "1404", "1", 3, "ندارد", "12", "3",
                   "RoghayehShokuhmand" ,True ))
        self.courses.append(
            Course("405", "پایان نامه", "1404", "1", 3, "ندارد", "12", "3",
                   "MehdiBagheri",True))
        print(self.courses)
    def add_an_object(self,obj):
        if type(obj) == Course:
            self.courses_file.append(obj.get_json_string())
        if type(obj) == Master:
            self.masters_file.append(obj.get_json_string())
        if type(obj) == RequestForThesisDefense:
            self.requests_file.append(obj.get_json_string())
        if type(obj) == Student:
            self.students_file.append(obj.get_json_string())

    def have_lacture_with(self,student_id, course):
        if (student_id, course.course_id) in self.has_course:
            raise Exception("شما قبلا این درس را اخذ نمودید!")
        if course.capacity != 0 :
            self.has_course.append((student_id, course.course_id))
            course.capacity -= 1
            emruz = date.today()
            emruz = emruz.strftime("%Y/%m/%d")
            self.tarixe_sabt.append(emruz)
        else :
            raise Exception("ظرفیت تکمیل شده")

    def delete_lacture_with(self,student, course):
        try:
            index_of_value = self.has_course.index((student.username, course.course_id))
            self.has_course.remove((student.username, course.course_id))
            course.capacity += 1
            del self.has_course[index_of_value]

        except:
            raise Exception("پیدا نشد")

    def have_request_for_thesis_defenses(self, defence):
        self.request_for_thesis_defenses.append(defence)

    def shut_down(self):
        self.masters_file.clear()
        self.courses_file.clear()
        self.requests_file.clear()
        self.students_file.clear()

        for master in self.masters:
            self.add_an_object(master)

        for course in self.courses:
            self.add_an_object(course)

        for item in self.requests:
            self.add_an_object(item)

        for item in self.students:
            self.add_an_object(item)

        with open("masters.json", "w", encoding="utf-8") as file:
            json.dump(self.masters_file, file)

        with open("courses_file.json", "w", encoding="utf-8") as file:
            json.dump(self.courses_file, file)

        with open("has_course.json", "w", encoding="utf-8") as file:
            json.dump(self.has_course, file)

        with open("request_for_thesis_defenses.json", "w", encoding="utf-8") as file:
            json.dump(self.request_for_thesis_defenses, file)

        with open("requests_file.json", "w", encoding="utf-8") as file:
            json.dump(self.requests_file, file)

        with open("students_file.json", "w", encoding="utf-8") as file:
            json.dump(self.students_file, file)

        with open("tarixe_sabt.json", "w", encoding="utf-8") as file:
            json.dump(self.tarixe_sabt, file)



    def turn_on(self):


        with open("tarixe_sabt.json", "r", encoding="utf-8") as file:
            self.tarixe_sabt = json.load(file)

        with open("masters.json", "r", encoding="utf-8") as file:
            self.masters_file = json.load(file)

        with open("courses_file.json", "r", encoding="utf-8") as file:
            self.courses_file = json.load(file)

        with open("has_course.json", "r", encoding="utf-8") as file:
            self.has_course = json.load(file)

        with open("request_for_thesis_defenses.json", "r", encoding="utf-8") as file:
            self.request_for_thesis_defenses = json.load(file)

        with open("requests_file.json", "r", encoding="utf-8") as file:
            self.requests_file = json.load(file)


        with open("students_file.json", "r", encoding="utf-8") as file:
            self.students_file = json.load(file)

        for master in self.masters_file:
            temp = Master("0","0","0","0")
            temp.load(master)
            self.masters.append(temp)

        for course in self.courses_file:
            temp = Course("0","0","0","0","0","0","0","0")
            temp.load(temp)
            self.courses.append(temp)

        for item in self.requests_file:
            temp = RequestForThesisDefense("0","0","0","0","0","0","0")
            temp.load(temp)
            self.requests.append(temp)

        for student in self.students_file:
            temp = Student("0","0","0","0")
            temp.load(student)
            self.masters.append(temp)
