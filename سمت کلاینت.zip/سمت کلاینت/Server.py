import os
import re
import hashlib
import uuid
from datetime import date , datetime
from flask import Flask, request, send_from_directory, jsonify
from flask import Flask, request, jsonify
from Object import DataBase, RequestForThesisDefense

app = Flask(__name__)

data_base = DataBase()


# ------------------------
# هندلر خطا برای پسورد اشتباه
# ------------------------
def wrong_password(*args, **kwargs):
    data = {"SUC": False, "message": "نام کاربری یا رمز عبور اشتباه است"}
    response = jsonify(data)
    response.status_code = 401
    return response


# ------------------------
# دکوریتورها
# ------------------------
def check_password_master(func):
    def wrapper(*args, **kwargs):
        username = request.form.get("username")
        password = request.form.get("password")

        if not username or not password:
            return wrong_password()

        hashed_pass = hashlib.sha512(password.encode("utf-8")).hexdigest()
        for item in data_base.masters:
            if item.username == username and item.hash_of_password == hashed_pass:
                return func(*args, **kwargs)

        return wrong_password()

    wrapper.__name__ = func.__name__
    return wrapper


def check_password_student(func):
    def wrapper(*args, **kwargs):
        username = request.form.get("username")
        password = request.form.get("password")

        if not username or not password:
            return wrong_password()

        hashed_pass = hashlib.sha512(password.encode("utf-8")).hexdigest()
        for item in data_base.students:
            if item.username == username and item.hash_of_password == hashed_pass:
                return func(*args, **kwargs)

        return wrong_password()

    wrapper.__name__ = func.__name__
    return wrapper


def check_password(func):
    def wrapper(*args, **kwargs):
        username = request.form.get("username")
        password = request.form.get("password")

        if not username or not password:
            return wrong_password()

        hashed_pass = hashlib.sha512(password.encode("utf-8")).hexdigest()
        for item in data_base.masters:
            if item["username"] == username and item["password"] == hashed_pass:
                return func(*args, **kwargs)
        for item in data_base.students:
            if item["username"] == username and item["password"] == hashed_pass:
                return func(*args, **kwargs)

        return wrong_password()

    wrapper.__name__ = func.__name__
    return wrapper


UPLOAD_FOLDER = "uploads"

@app.route("/upload", methods=["POST"])
def upload_file():
    unique_code = str(uuid.uuid4())
    file = request.files.get("file")
    if not file:
        return jsonify({"error": "هیچ فایلی ارسال نشده"}), 400

    path = os.path.join(UPLOAD_FOLDER, unique_code)
    file.save(path)
    return jsonify({"message": "فایل ذخیره شد", "download_url": f"/download/{unique_code}"})


# دانلود فایل
@app.route("/download/<filename>", methods=["GET"])
def download_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)




# ------------------------
# کارای دانشجو
# ------------------------

@app.route("/axze_dars", methods=["POST"])
@check_password_student
def axze_dars():
    try:
        input_stream = request.form
        for dars in data_base.courses:
            if dars.course_id == input_stream["course_id"]:
                data_base.have_lacture_with(input_stream["username"], dars)

        data = {"SUC": True, "message": "با موفقیت ثبت شد"}
        response = jsonify(data)
        response.status_code = 200
        return response
    except Exception as e:
        data = {"SUC": False, "message": str(e)}
        response = jsonify(data)
        return response


@app.route("/hazfe_dars", methods=["POST"])
@check_password_student
def hazfe_dars():
    try:
        input_stream = request.form
        for dars in data_base.courses:
            if dars.course_id == input_stream["course_id"]:
                data_base.delete_lacture_with(dars.student, dars.course)

        data = {"SUC": True, "message": "با موفقیت حذف شد"}
        response = jsonify(data)
        response.status_code = 200
        return response
    except Exception as e:
        data = {"SUC": False, "message": str(e)}
        response = jsonify(data)
        response.status_code = 200
        return response


@app.route("/vaziyate_darxast_ha_student", methods=["POST"])
@check_password_student
def vaziyate_darxast_ha_student():
    data = []
    for read in data_base.requests:
        if read.Student_id == request.form["username"]:
            for mas in data_base.masters:
                if mas.username == read.OstadAsliId:
                    data.append(
                        {
                            "master_name": mas.name,
                            "status": read.Ostad_QabulKard_Defa_Kone,
                            "id": read.ID,
                        }
                    )

    response = jsonify(data)
    response.status_code = 200
    return response


@app.route("/darxaste_defa", methods=["POST"])
@check_password_student
def darxaste_defa():
    input = request.form
    reviewers_list = input["reviewers"].split(" ")

    data = {"message" : "خودمم موندم چیکار کردی که این پبام چاپ شد!"}
    # شی استاد رو پیدا کن
    supervisor = None
    for master in data_base.masters:
        if master.username == input["supervisor"]:
            supervisor = master
    if supervisor is None:
        data = {"message": "استاد راهنمای مورد نظر یافت نشد"}
        response = jsonify(data)
        response.status_code = 200
        return response

    payan_name_course = None
    dars_haye_daneshcu = [tup[1] for tup in data_base.has_course if tup[0] == input["username"]]
    #تک تک کرس ها رو بگرد اگه شرط هم استادش استاد مورد نظر بود هم درسش پایان نامه حلقه رو بشکن
    for code_dars in dars_haye_daneshcu:
        for dars in data_base.courses:
            if dars.course_id == code_dars and dars.teacher_id == input["supervisor"] and dars.is_sort_of_payan_name == True:
                payan_name_course = dars

    if payan_name_course is None:
        data = {"message": "شما با استاد راهنمای مورد نظر درس پایان نامه ندارید"}
        response = jsonify(data)
        response.status_code = 200
        return response

    emruz = date.today()
    emruz_tb = emruz.strftime("%Y/%m/%d")
    emruz_tb = datetime.strptime(emruz_tb,"%Y/%m/%d")
    unruz = datetime.strptime(data_base.tarixe_sabt[data_base.has_course.index( (input["username"] , payan_name_course.course_id ))], "%Y/%m/%d")
    #if (emruz_tb- unruz).days <= 90 :
    #    data = {"message": "حداقل باید سه ماه از ثبت درس گذشته باشه"}
    #    response = jsonify(data)
    #    response.status_code = 200
    #    return response


    all_masters_id = [master.username for master in data_base.masters]
    for reviewer in reviewers_list:
        if reviewer not in all_masters_id:
            data = {"message": "یکی از داوران یافت نشد"}
            response = jsonify(data)
            response.status_code = 200
            return response


    emruz = emruz.strftime("%Y/%m/%d")
    new_item = RequestForThesisDefense (emruz, input["fileLiknk"] , input["title"] , input["abstract"] , input["keywords"] , input["reviewers"],"دربررسی" ,supervisor.username ,input["username"])
    data_base.requests.append(new_item)

    data = {"message": "درخواست شما با موفقیت ثبت شد"}
    response = jsonify(data)
    response.status_code = 200
    return response


@app.route("/neshan_dadan_dars_qabel_axz", methods=["POST"])
@check_password_student
def neshan_dadan_dars_qabel_axz():
    input = request.form
    output = []

    # پیدا کردن استاد
    found_master = None
    for mas in data_base.masters:
        if mas.name == input["name_ostad"]:
            found_master = mas

    if found_master is not None:
        for course in data_base.courses:
            if course.title == input["onvan_dars"] or input["onvan_dars"] == "":
                if course.half_year == input["nimsal"] or input["nimsal"] == "":
                    if course.year == input["sal"] or input["sal"] == "":
                        if found_master.name == input["name_ostad"]:
                            write = course.saving_buffer.copy()
                            write["teacher_id"] = found_master.name
                            output.append(write)

    if input["name_ostad"] == "":
        for course in data_base.courses:
            if course.title == input["onvan_dars"] or input["onvan_dars"] == "":
                if course.half_year == input["nimsal"] or input["nimsal"] == "":
                    if course.year == input["sal"] or input["sal"] == "":
                        write = course.saving_buffer.copy()
                        for mast in data_base.masters:
                            if mast.username == write["teacher_id"]:
                                write["teacher_id"] = mast.name
                                output.append(write)
    print(output)
    response = jsonify(output)
    response.status_code = 200
    return response


# ------------------------
# کارای مشترک استاد و دانشجو
# ------------------------
@app.route("/get_name", methods=["POST"])
def get_name ():
    data = {"name": "ناشناس"}
    for mas in data_base.masters:
        if request.form.get("username") == mas.username:
            data["name"] = "استاد "  + mas.name
            break
    for stu in data_base.students:
        if request.form.get("username") == stu.username:
            data["name"] = stu.name
            break

    response = jsonify(data)
    response.status_code = 200
    return response


@app.route("/login", methods=["POST"])
def login():
    has_input_pass = hashlib.sha512(request.form["password"].encode("utf-8")).hexdigest()

    for master in data_base.masters:
        if (
            master.username == request.form["username"]
            and master.hash_of_password == has_input_pass
        ):
            data = {"Success": True, "Rule": "master"}
            response = jsonify(data)
            response.status_code = 200
            return response

    for student in data_base.students:
        if (
            student.username == request.form["username"]
            and student.hash_of_password == has_input_pass
        ):
            data = {"Success": True, "Rule": "student"}
            response = jsonify(data)
            response.status_code = 200
            return response

    data = {"Success": False}
    response = jsonify(data)
    response.status_code = 200
    return response


@app.route("/josto_ju_dar_banke_payannameh", methods=["POST"])
def josto_ju_dar_banke_payannameh():
    output = []
    kk_vorudi = re.findall(r"#\w+", request.form["kalamate_kelidi"])

    if request.form["nevisande"] == "":
        for req in data_base.requests:
            if request.form["sal"] in req.TarixeDarxasteDefa or request.form["sal"] == "":
                if kk_vorudi :
                    for klm in kk_vorudi:
                        if request.form["kalamate_kelidi"] == "" or klm in req.KalamateKelidiDefa:
                            if req.kamel_shod():
                                output.append(req.saving_buffer)
                else:
                    if req.kamel_shod():
                        output.append(req.saving_buffer)
    else:
        st_id = 0
        for st in data_base.students:
            if st.name == request.form["nevisande"]:
                st_id = st.ID
        for req in data_base.requests:
            if request.form["sal"] in req.TarixeDarxasteDefa or request.form["sal"] == "":
                if st_id == req.Student_id:
                    if kk_vorudi :
                        for klm in kk_vorudi:
                            if request.form["kalamate_kelidi"] == "" or klm in req.KalamateKelidiDefa:
                                if req.kamel_shod():
                                    output.append(req.saving_buffer)
                    else:
                        if req.kamel_shod():
                            output.append(req.saving_buffer)

    response = jsonify(output)
    response.status_code = 200
    return response


# ------------------------
# کارای استاد
# ------------------------

@app.route("/moshahede_liste_davari", methods=["POST"])
@check_password_master
def moshahede_liste_davari():
    output = []
    for req in data_base.requests:
        if request.form["username"] in req.AsatideRahnemaVaNomarateshunDefa:
            output.append(req.saving_buffer)

    response = jsonify(output)
    response.status_code = 200
    return response


@app.route("/sabte_nomreh_davari", methods=["POST"])
@check_password_master
def sabte_nomreh_davari():
    ostad = None
    for master in data_base.masters:
        if master.username == request.form["username"]:
            ostad = master
            break

    for req in data_base.requests:
        if req.ID == request.form["req-id"]:
            req.AsatideRahnemaVaNomarateshunDefa = req.AsatideRahnemaVaNomarateshunDefa.replace(
                request.form["username"], ostad.name + " : " + request.form["grade"]
            )

            data = {"Suc": True}
            response = jsonify(data)
            response.status_code = 200
            return response

    data = {"Suc": False}
    response = jsonify(data)
    response.status_code = 200
    return response


@app.route("/moshahede_darxaste_defa", methods=["POST"])
@check_password_master
def moshahede_darxaste_defa():
    output = []
    for req in data_base.requests:
        if req.OstadAsliId == request.form["username"] and req.Ostad_QabulKard_Defa_Kone == "دربررسی":
            output.append(req.saving_buffer)

    response = jsonify(output)
    response.status_code = 200
    return response


@app.route("/taid_darxaste_defa", methods=["POST"])
@check_password_master
def taid_darxaste_defa():
    for req in data_base.requests:
        print (req.ID +"\n"+ request.form["req-id"])
        if req.ID == request.form["req-id"] and req.OstadAsliId == request.form["username"]:
            req.Ostad_QabulKard_Defa_Kone = "قبول شد"
            data = {"Suc": True}
            response = jsonify(data)
            response.status_code = 200
            return response

    data = {"Suc": False}
    response = jsonify(data)
    response.status_code = 200
    return response


@app.route("/rade_darxaste_defa", methods=["POST"])
@check_password_master
def rade_darxaste_defa():
    for req in data_base.requests:
        if req.ID == request.form["req-id"] and req.OstadAsliId == request.form["username"]:
            req.Ostad_QabulKard_Defa_Kone = "رد شد"
            data = {"Suc": True}
            response = jsonify(data)
            response.status_code = 200
            return response

    data = {"Suc": False}
    response = jsonify(data)
    response.status_code = 200
    return response


# ------------------------
# اجرای برنامه
# ------------------------
if __name__ == "__main__":
    app.run(debug=True)
